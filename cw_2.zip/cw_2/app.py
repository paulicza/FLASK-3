from flask import Flask, render_template

app = Flask(__name__)

# Przykładowe dane rozdziałów
chapters = {
    1: "Treść Rozdziału 1...",
    2: "Treść Rozdziału 2...",
    3: "Treść Rozdziału 3...",
    # Dodaj kolejne rozdziały według potrzeby
}

@app.route('/')
def index():
    return render_template('index2.html', title='pierwszy paragraf')

@app.route('/chapter/<int:chapter_num>')
def chapter(chapter_num):
    chapter_content = chapters.get(chapter_num, "Nie znaleziono rozdziału.")
    return render_template('base2.html', title=f"Rozdział {chapter_num}", chapter_content=chapter_content)

if __name__ == '__main__':
    app.run(debug=True)