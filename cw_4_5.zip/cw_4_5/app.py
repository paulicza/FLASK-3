from flask import Flask, render_template, jsonify, make_response

app = Flask(__name__)

# Przykładowe dane rozdziałów
chapters = {
    1: "Treść Rozdziału 1...",
    2: "Treść Rozdziału 2...",
    3: "Treść Rozdziału 3...",
    # Dodaj kolejne rozdziały według potrzeby
}

@app.route('/')
def index():
    return render_template('index.html', title='Strona Główna')

@app.route('/chapter/<int:chapter_num>')
def chapter(chapter_num):
    chapter_content = chapters.get(chapter_num, "Nie znaleziono rozdziału.")
    return render_template('base2.html', title=f"Rozdział {chapter_num}", chapter_content=chapter_content)

# Obsługa błędów
#jsonify konwertuje dane na format json i ustawia odpowiendi nagłówek 
@app.errorhandler(400)
def bad_request(error):
    return make_response(jsonify({'error': 'Niepoprawne żądanie'}), 400)

@app.errorhandler(401)
def unauthorized(error):
    return make_response(jsonify({'error': 'Brak autoryzacji'}), 401)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Nie znaleziono'}), 404)

@app.errorhandler(500)
def internal_server_error(error):
    return make_response(jsonify({'error': 'Błąd serwera'}), 500)

@app.errorhandler(504)
def gateway_timeout(error):
    return make_response(jsonify({'error': 'Przekroczono czas oczekiwania na odpowiedź'}), 504)

if __name__ == '__main__':
    app.run(debug=True)