from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    borrowings = db.relationship('Borrowing', backref='borrower', lazy='dynamic')

    def __repr__(self):
        return f'<User {self.username}>'

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128))
    author = db.Column(db.String(128))
    available = db.Column(db.Boolean, default=True)
    borrowings = db.relationship('Borrowing', backref='book', lazy='dynamic')

    def __repr__(self):
        return f'<Book {self.title}>'

class Borrowing(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'))
    timestamp = db.Column(db.DateTime, index=True) #, default=datetime.utcnow

    def __repr__(self):
        return f'<Borrowing {self.user_id} {self.book_id}>'

def add_sample_data():
    from app import create_app
    app = create_app()
    app.app_context().push()
    
    db.drop_all()
    db.create_all()

    user1 = User(username='Monika Gopek')
    user2 = User(username='Paulina Gopek')

    book1 = Book(title='Władca Pierścieni', author='J.R.R. Tolkien')
    book2 = Book(title='Hobbit', author='J.R.R. Tolkien')
    book3 = Book(title='Harry Potter i Kamień Filozoficzny', author='J.K. Rowling')
    book4 = Book(title='Harry Potter i Komnata Tajemnic', author='J.K. Rowling')
    book5 = Book(title='Duma i uprzedzenie', author='Jane Austen')

    db.session.add(user1)
    db.session.add(user2)
    db.session.add(book1)
    db.session.add(book2)
    db.session.add(book3)
    db.session.add(book4)
    db.session.add(book5)

    db.session.commit()

    print("Przykładowe dane zostały dodane pomyślnie.")
