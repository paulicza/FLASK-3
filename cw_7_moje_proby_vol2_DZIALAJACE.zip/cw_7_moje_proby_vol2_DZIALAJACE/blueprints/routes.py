from flask import Blueprint, render_template, redirect, url_for, request
from blueprints.base_dates import db, User, Book, Borrowing
from blueprints.forms import BorrowForm

routes = Blueprint('routes', __name__)

@routes.route('/')
def index():
    return render_template('index.html')

@routes.route('/books')
def books():
    books = Book.query.all()
    return render_template('books.html', books=books)

@routes.route('/borrow/<int:book_id>', methods=['GET', 'POST'])
def borrow(book_id):
    book = Book.query.get_or_404(book_id)
    form = BorrowForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and book.available:
            borrowing = Borrowing(user_id=user.id, book_id=book.id)
            db.session.add(borrowing)
            book.available = False
            db.session.commit()
            return redirect(url_for('routes.books'))
    return render_template('borrow.html', book=book, form=form)