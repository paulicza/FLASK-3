from flask import Flask
from blueprints.simple_page import simple_page  # Importujemy blueprint
from blueprints.appzcw2 import appzcw2

app = Flask(__name__)
app.register_blueprint(simple_page)
app.register_blueprint(appzcw2)

@app.route('/')
def index():
    return ('joł')

if __name__ == '__main__':
    app.run(debug=True)