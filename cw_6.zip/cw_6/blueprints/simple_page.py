from flask import Blueprint

simple_page = Blueprint('simple_page', __name__)

#from . import routes
@simple_page.route('/home')
def home():
    return "Witaj na stronie głównej!"