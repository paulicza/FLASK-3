from flask import Blueprint, render_template

appzcw2 = Blueprint('appzcw2', __name__)

# Przykładowe dane rozdziałów
chapters = {
    1: "Treść Rozdziału 1...",
    2: "Treść Rozdziału 2...",
    3: "Treść Rozdziału 3...",
    # Dodaj kolejne rozdziały według potrzeby
}

@appzcw2.route('/chapter/<int:chapter_num>')
def chapter(chapter_num):
    chapter_content = chapters.get(chapter_num, "Nie znaleziono rozdziału.")
    return render_template('base2zcw2.html', title=f"Rozdział {chapter_num}", chapter_content=chapter_content)
