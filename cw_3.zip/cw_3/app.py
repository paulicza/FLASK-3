from flask import Flask, render_template

app = Flask(__name__)

@app.route('/chapter/<int:chapter_num>')
def chapter(chapter_num):
    return render_template('base2.html', title=f"Rozdział {chapter_num}", chapter_num=chapter_num)

if __name__ == '__main__':
    app.run(debug=True)
