from flask import Blueprint, render_template, redirect, url_for, request
from blueprints.base_dates import db, User, Book, Borrowing
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

routes = Blueprint('routes', __name__)

class BorrowForm(FlaskForm): #WPROWADZAM IMIE I NAZWISKO BY WYPOZYCZYC; ZA ISTENIENIE DANYCH (I WYPOZYCZENIE) ODPOWIADA ENDPOINT BORROW
    username = StringField('Username', validators=[DataRequired()])
    submit = SubmitField('Borrow')

@routes.route('/')
def index():
    return render_template('index.html', page_title='BIBLIOTEKA ONLINE')

@routes.route('/books')
def books():
    books = Book.query.all() #POBIERANIE Z BAZY DANYCH WSZYTSKICH KSIĄŻEK
    return render_template('books.html', books=books, page_title="BAZA KSIĄŻEK")

@routes.route('/borrow/<int:book_id>', methods=['GET', 'POST']) #identyfikatory książek; sql automatycznie je nadaje po dodaniu do bazy książek
def borrow(book_id):
    book = Book.query.get_or_404(book_id) #jeśli książka nieistnieje to bład
    form = BorrowForm() #TWORZENIE INSTANCJI FORMULARZA DO POBIERANIA DANYCH WPROWADZONYCH PRZE ZUŻYTKOWNIKA
    if form.validate_on_submit(): #czy formularz został przesłany (kliknięty submit i poprawne dane)
        user = User.query.filter_by(username=form.username.data).first() #pobieranie info o użytkownika; User.query -tabela użytkowników w bazie; .first() zwraca pierwszy rekord; form.username.date - to co wprowadził uzytkownik w formularzu
        if user and book.available: #czy uzytkownik istnieje i czy książka dostepna
            borrowing = Borrowing(user_id=user.id, book_id=book.id) #tworzone nowe wypożyczenie 
            db.session.add(borrowing) #zapisujemy wypożyczenie w bazie danych
            book.available = False #ustawienie statusu książki na niedostępną
            db.session.commit()
            return redirect(url_for('routes.books')) #przeniesieniu na liste książek
    return render_template('borrow.html', book=book, form=form, page_title="WYPOŻYCZALNIA") #skorzystanie z wyglądu formularza