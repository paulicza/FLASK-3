from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bootstrap import Bootstrap
from blueprints.routes import routes
from blueprints.base_dates import add_sample_data
import os

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///example.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = 'tutaj_wstaw_swoj_tajny_klucz'

    #inicjalizacja bootstrapa
    Bootstrap(app)
     # Inicjalizacja bazy danych
    from blueprints.base_dates import db
    db.init_app(app)

    # Rejestracja blueprintów
    app.register_blueprint(routes)

    return app

if __name__ == '__main__':
    app = create_app()
    app.app_context().push()  # Dodaj ten wiersz, aby kontekst aplikacji był dostępny dla add_sample_data()
    
    # Wywołaj funkcję add_sample_data()
    add_sample_data()
    app.run(debug=True)
