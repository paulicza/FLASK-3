from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', title='Witaj w Flask!', title1='yeyyy')

@app.route('/omnie')
def omnie():
    return render_template('about.html', surname='Paulina', name='Gopek', age='21', title='o mnie')

if __name__ == '__main__':
    app.run(debug=True)